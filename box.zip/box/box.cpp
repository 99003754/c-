#include "box.h"

Box::Box()::m_length{0},m_breadth{0},m_height(0)
   {

   }
