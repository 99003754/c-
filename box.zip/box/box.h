#include <iostream>
using namespace std;

class Box
{
    int m_length;
    int m_breadth;
    int m_height;

    public:
    Box();
    int length()
    {
        return m_length;
    }
    int breadth()
    {
        return m_breadth;
    }
    int height()
    {
        return m_height;
    }
    void display()
    {
        std::cout<<"Length = "<<m_length<<"Breadth = "<<m_breadth<<"height ="<<m_height<<endl;
    }

};

