#include "box.h"
#include "gtest/gtest.h"


GTEST_TEST(Empty_const,Box)
{
 Box c1;
EXPECT_EQ(0,c1.length());
EXPECT_EQ(0,c1.breadth());
EXPECT_EQ(0,c1.height());
}

int main(int argc,char **argv)
{
  ::testing::InitGoogleTest(&argc,argv);
  return RUN_ALL_TESTS();
}
